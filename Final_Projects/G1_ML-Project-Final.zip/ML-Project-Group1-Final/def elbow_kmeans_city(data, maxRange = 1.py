import numpy as np
import matplotlib as plt

def elbow_kmeans_city(data, maxRange = 10):
    try:
        X_w = data.drop('City',1)
        X_w = MinMaxScaler().fit_transform(X_w)
    except:
        X_w = MinMaxScaler().fit_transform(data)
    Error =[]
    for i in range(1, maxRange+1):
        kmeans = KMeans(n_clusters = i).fit(X_w)
        kmeans.fit(X_w)
        Error.append(kmeans.inertia_)
    plt.plot(range(1, maxRange+1), Error)
    plt.title('Elbow method')
    plt.xlabel('No of clusters')
    plt.ylabel('Error')
    plt.show()
    
    return(X_w)